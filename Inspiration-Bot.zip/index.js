const Discord = require('discord.js');
const InspirationDiscordBot = new Discord.Client();
const InspirationToken = 'NzU4NDg5NTQwMjI2MTg3MzE0.X2vsbg.UjijMrB9IgHA0_of5HgSAkVyT-0';
InspirationDiscordBot.login(InspirationToken);

const fs = require('fs')
let bigArray;
try {
  const data = fs.readFileSync('library.txt',)
  bigArray = data.toString().split("\n").map(function(el){ return el.split(";");})
} catch (err) {
 console.error(err)
}

let images;
try {
  const dataImages = fs.readFileSync('img.txt',)
  images = dataImages.toString().split("\n")
} catch (err) {
 console.error(err)
}
console.log(images[1]);

InspirationDiscordBot.login(InspirationToken);



//tells me that Maxima is ready
InspirationDiscordBot.on('ready', () =>{
  const MainChannel = InspirationDiscordBot.channels.cache.get('767140931412688897');
  console.log('The Inspiration Bot is gonna spit some mad bars.');

//embed message

  function SendQuotes() {
    var randomColor = '#'+ Math.floor(Math.random()*16777215).toString(16);
    var index = Math.floor(bigArray.length * Math.random());
    var randomQuote = bigArray[index];
    console.log(images[1]);
    var quoteEmbed = new Discord.MessageEmbed()
    .setColor(randomColor)
    .setTitle('Hourly Inspirational Quote')
    .setDescription(randomQuote[0] + "\n\n-" + randomQuote[1] + "\n" + randomQuote[2])
    .setAuthor(randomQuote[1],randomQuote[3])
    .setThumbnail(randomQuote[3])
    .setImage(images[Math.floor(images.length * Math.random())])
    .setFooter('This is your hourly quote. We love you :)')
    .setTimestamp()
    ;

    MainChannel.send(quoteEmbed);
  }

setInterval(() => {
  SendQuotes();
}, 10000);

});
